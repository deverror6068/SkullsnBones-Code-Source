﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Drawing;
using System.Windows.Forms;

namespace Skullsnbones
{
    class Bullet
    {
        public string direction;
        public int bulletLeft;
        public int bulletTop;

        private int speed = 20;   //vitesse de la balle 
        private PictureBox bullet = new PictureBox();
        private Timer bulletTimer = new Timer(); //minuterie de la vitesse de la balle 


        public void MakeBullet(Form form)
        {

            bullet.BackColor = Color.White; //"couleur" de la balle 
            bullet.Size = new Size(5,5); //taille de la balle 
            bullet.Tag = "bullet";
            bullet.Left = bulletLeft;
            bullet.Top = bulletTop;
            bullet.BringToFront();   

            form.Controls.Add(bullet);


            bulletTimer.Interval = speed;
            bulletTimer.Tick += new EventHandler(BulletTimerEvent);
            bulletTimer.Start();

        }

        private void BulletTimerEvent(object sender, EventArgs e)
        {

            if (direction == "left")       //déplacement de la balle 
            {
                bullet.Left -= speed;
            }

            if (direction == "right")
            {
                bullet.Left += speed;
            }

            if (direction == "up")
            {
                bullet.Top -= speed;
            }

            if (direction == "down")
            {
                bullet.Top += speed;
            }


            if (bullet.Left < 10 || bullet.Left > 860 || bullet.Top < 10 || bullet.Top > 600) //si la balle sort de la zone de jeu 
            {
                bulletTimer.Stop();     //arret de la minuterie 
                bulletTimer.Dispose();  //supression du timer
                bullet.Dispose();      //supression de la balle 
                bulletTimer = null;   
                bullet = null;
            }



        }



    }
}
