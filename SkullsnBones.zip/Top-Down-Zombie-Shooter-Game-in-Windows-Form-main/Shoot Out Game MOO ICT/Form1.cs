﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using Google.Protobuf.WellKnownTypes;
using MySql.Data.MySqlClient;
using Org.BouncyCastle.Tls;

namespace Skullsnbones
{

    public partial class Form1 : Form
    {

        bool goLeft, goRight, goUp, goDown, gameOver;    // permet de connaitre la direction 
        bool isInpause = false;                         //détermine si il faut remettre en pause ou le faire reprendre quand le joueur appuie sur P
        string facing = "up";                           // permet de savoir quel sprite directionnel appliquer au joueur quand il prend des dégats 
        bool dataSend = false;                          //les données de jeu ont été envoyées à la base de donnée ? 

        int playerHealth = 100;      //sante du joueur
        int playerSpeed = 10;       //vitesse de déplacement du joueur 
        int playerAmmo = 10;        //munition du joueur
        int zombieSpeed = 1;        //vitesse de déplacement des zombies 
        int player_maxAmmo = 25;    //nombre de munition maximum du zombie 


        Random randNum = new Random();    // permet de générer des nombre alléatoire
         
        int playerKills;        //nombre d'élimination du joueur
        int zombieKilled = 0;   
        int gameWave = 1;       //vague de zombie actuelle


        bool is_wave_wait_subscribed = false;       // permet de gérer l'évènement de minuterie de vague (compte à rebours)
        bool is_spawner_handler_subscribed = false;

        int wave_zombiesIngame = 5;               //determine le nombre de zombies  en vie  quand il tombe à zéro le nombre de la vague actuelle s'incrémente
        int wave_zombieSummoned = 0;             //nombre de zombie qui ont déja été invoqués
        int wave_zombies_Tohave = 5;             //nombre de zombie par vague ; il augmente de 3 à chaque vague passée
        int wave_zombie_killed = 0;
        
        bool finishedwave = false;
        int duration_waveMessage = 5;        //durée durant le message de vague s'affiche
        int zombie_spawnDelay = 2;
        public bool isClosed = false;
        string playerName;                  //nom du joueur ; récupéré dans l'input du form 2
        int game_WaitDuration = 5;          //durée du compte à rebours avant la première vague quand le jeu est lancé pour la première fois 
       
        Timer WaitPlayer = new Timer();         //minuterie du compte à rebours avant la première vague
        Timer WaitWaveMessage = new Timer();    //minuterie du texte de vague  
        Timer SpawnZombie = new Timer();

        List<PictureBox> zombiesList = new List<PictureBox>();  //contient tout les zombies
        List<PictureBox> healList = new List<PictureBox>();     //contient toutes les trousses dev soins 
        List<PictureBox> bulletList = new List<PictureBox>();   //contient tout les sacs de munitions 

        public int playerScore = 0;  //score du joueur 



        public Form1()
        {
       
            this.FormClosed += Form1_FormClosed; //associe la fonction evènementielle  à l'evènement  "fermeture de form1"


        }


        private void Form1_FormClosed(Object sender, FormClosedEventArgs e)  //fonction évenementielle 
        {

      
            GameTimer.Stop();  //quand Form2 (le jeu) est fermé 

                string message = "Do you want to see  yours results ?";
                string caption = "Game Closed";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;            //propose les bouton oui et non à l'utilisateur 
                DialogResult result; 

                // Affiche la fenetre de dialogue .

                result = MessageBox.Show(this, message, caption, buttons);

                if (result == DialogResult.Yes)                 // si le résultat est oui 
                {

                  //ouvre dans le navigateur par défaut le site de Skulls 'n Bones 


                ProcessStartInfo sInfo = new ProcessStartInfo("https://skullnboneofficialsite.free.nf/?i=1");
                Process.Start(sInfo);

                System.Windows.Forms.Application.Exit();            //ferme le jeu
               
            }
            else
            {
                
                System.Windows.Forms.Application.Exit();            //ferme le jeu
            }
            


        }

        public void SetPlayerName(string playername)  // affectation de la valeur de l'input de form 1 à la variable 
        {
            playerName = playername;
        }


        async private void MainTimerEvent(object sender, EventArgs e) // fonction principale du jeu 
        {


            if(playerHealth < 25)                           //coloration de la barre de vie en fonction de la santé du joueur 
            {
                this.healthBar.ForeColor = Color.Red;
            }
            if (playerHealth < 65  && playerHealth >25)         
            {
                 this.healthBar.ForeColor = Color.Orange;
            }
          
            if (playerHealth > 1)                          //si le joueur est en vie la barre de vie s'actualise avec la vie du joueur 
            {
                healthBar.Value = playerHealth;
            }
            else                                             //le joueur est mort 
            {
              
                gameOver = true;                            //fin du jeu
                this.Enabled = true;                        
                healthBar.Value = 0;                        //la barre de vie est vide 
                playerBox.Image = skullsnbones.Properties.Resources.dead;            //on change l'image du joueur 
                gameOverMsg.Visible = true;                 //le message de fin de jeu s'affiche 
                gameOverMsg.BringToFront();                 //mise au premier plan du message 
                GameTimer.Stop();                           // arret de la minuterie du jeu 
                
                await Task.Delay(1000);                     // Permet qu'il n'y pas de ralentissement du jeu qui fasse que le message de fin s'affiche avant que l'on voie le cadavre du joueur en  reportant de 1s l'enregistrement des donnée vers la bdd
                



                SendDataToDataBase();  //appel de la fonction d'enregistrement des données de jeu vers la BDD
                dataSend = true;
                
            }

            ammoLabel.Text = "" + playerAmmo;  //   actualisation des valeurs de jeu (munitions,kills,score) pour les  texte de l'UI  
            killsLabel.Text = "" + playerKills;
            this.scoreLabel.Text = "" + playerScore;

            if (goLeft == true && playerBox.Left > 0) //permet au joueur  de se déplacer 
            {
                playerBox.Left -= playerSpeed;
            }
            if (goRight == true && playerBox.Left + playerBox.Width < this.ClientSize.Width)
            {
                playerBox.Left += playerSpeed;
            }
            if (goUp == true && playerBox.Top > 45)
            {
                playerBox.Top -= playerSpeed;
            }
            if (goDown == true && playerBox.Top + playerBox.Height < this.ClientSize.Height)
            {
                playerBox.Top += playerSpeed;
            }



            foreach (Control x in this.Controls)  // si le joueur marche sur une boite de munition
            {
                if (x is PictureBox && (string)x.Tag == "ammo")
                {
                    if (playerBox.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(x);            //on enleve le sprite 
                        ((PictureBox)x).Dispose(); 
                        playerAmmo += 5;                    //on ajoute 5 munitions au joueur 
                        playerScore = playerScore + 15;                     //le score augmente 
                        ammoLabel.ForeColor = System.Drawing.Color.White;   //le texte redevient normal si le joueur était à court de munitions précèdement

                    }
                }

                if (x is PictureBox && (string)x.Tag == "heal")   //si un sprite  marche sur une trousse de soin
                {

                    if (playerBox.Bounds.IntersectsWith(x.Bounds))      // si le joueur marche sur une trousse de soin
                    {
                       

                        if (playerHealth < 100)
                        {
                            this.Controls.Remove(x);        //on enleve le sprite 
                            healList.RemoveAt(healList.Count - 1); //on enlève la trousse du nombre de trousse présentes en jeu 
                          ((PictureBox)x).Dispose();
                            this.healthBar.ForeColor = Color.Red;   
                            playerHealth = playerHealth + 25; 
                            playerScore = playerScore + 25;             //ajout de score au joueur
                            playerHealth = 100;                         //le joueur regagne toute sa vie 
                            this.healthBar.ForeColor = System.Drawing.Color.Green;    
                        }


                    }

                }



                if (x is PictureBox && (string)x.Tag == "zombie")       // si un sprite à une collision avec un zombie 
                {

                    if (playerBox.Bounds.IntersectsWith(x.Bounds))      // si le joueur percute un zombie
                    {
                        playerHealth -= 1;                              //le joueur prend un dégat par tick
                         

                        if (playerHealth > 0)                           //tant que le jouer est en vie  il peut se déplacer 
                        {
                            if (goLeft || goRight || goDown || goUp)
                            {
                                if (goLeft == true)
                                {

                                    this.playerBox.Image = skullsnbones.Properties.Resources.left___hurt;           //le joueur change de sprite selon sa direction
                                }
                                if (goRight == true)
                                {

                                    this.playerBox.Image = skullsnbones.Properties.Resources.right_hurt;
                                }
                                if (goDown == true)
                                {

                                    this.playerBox.Image = skullsnbones.Properties.Resources.down___hurt;
                                }
                                if (goUp == true)
                                {
                                    this.playerBox.Image = skullsnbones.Properties.Resources.up__hurt;

                                }

                            }
                            else
                            {
                                                                                                                 //le joueur change de sprite selon sa direction

                                if (facing == "up")
                                {
                                    this.playerBox.Image = skullsnbones.Properties.Resources.up__hurt;
                                }
                                if (facing == "down")
                                {
                                    this.playerBox.Image = skullsnbones.Properties.Resources.down___hurt;
                                }
                                if (facing == "left")
                                {
                                    this.playerBox.Image = skullsnbones.Properties.Resources.left___hurt;
                                }
                                if (facing == "right")
                                {
                                    this.playerBox.Image = skullsnbones.Properties.Resources.right_hurt;
                                }


                            }

                        }




                    }


                    if (x.Left > playerBox.Left)
                    {
                        x.Left -= zombieSpeed;
                        ((PictureBox)x).Image = skullsnbones.Properties.Resources.zleft;
                    }
                    if (x.Left < playerBox.Left)
                    {
                        x.Left += zombieSpeed;
                        ((PictureBox)x).Image = skullsnbones.Properties.Resources.zright;                //le joueur change de sprite selon sa direction
                    }
                    if (x.Top > playerBox.Top)
                    {
                        x.Top -= zombieSpeed;
                        ((PictureBox)x).Image = skullsnbones.Properties.Resources.zup;
                    }
                    if (x.Top < playerBox.Top)
                    {
                        x.Top += zombieSpeed;
                        ((PictureBox)x).Image = skullsnbones.Properties.Resources.zdown;
                    }

                }



                foreach (Control j in this.Controls)  //gestion des projectiles
                {
                    if (j is PictureBox && (string)j.Tag == "bullet" && x is PictureBox && (string)x.Tag == "zombie") //si une balle touche un zombie 
                    {
                        if (x.Bounds.IntersectsWith(j.Bounds))
                        {
                            playerKills++;                              //le nombre de kills s'incrémente 
                            zombieKilled = zombieKilled + 1;        
                   
                            playerScore = playerScore + 50;                      //augmentaion du score
                              
                         
                            int healdropNumber = randNum.Next(1, 10);            // à chaque fois qu'un zombie meurt selon le chiffre choisi il peut laisser tomber du soin ou des munitions
                            int bulletdropNumber = randNum.Next(1, 10);

                           
                            if (healdropNumber == 5)                             //selon le chiffre choisi il laisse tomber du soin, des munitions ou rien 
                            {
                                DropHeal(x);                                     //crée un sprite
                               
                            }
                            if (bulletdropNumber == 1)
                            {
                                
                                LootAmmo(x);                                    //crée un sprite      
                               
                            }

                      
                            this.Controls.Remove(j);         //on enlève les sprite du zombie et de la balle 
                            ((PictureBox)j).Dispose();
                            this.Controls.Remove(x);
                            ((PictureBox)x).Dispose();
                            zombiesList.Remove(((PictureBox)x));                    //on enlève le zombie de la liste des zombies en jeu  et de la variable 
                            wave_zombiesIngame = wave_zombiesIngame - 1;       
                            wave_zombie_killed++;                           
                            if (wave_zombiesIngame <= 0)                            //si tout les zombies ont été tués
                            {
                                
                                gameWave ++;                                         // le chiffr'e de la vague s'incrémente
                                WaveMsg.Text = "Wave" + gameWave;                   //actualisation du chiffre de la vague 
                                this.waveLabel.Text = "Wave " + gameWave;
                                wave_zombieSummoned = 0;                             //réinitalisation du nombre de zombies invoqués
                                wave_zombie_killed = 0;
                                wave_zombies_Tohave = wave_zombies_Tohave +3;        //on ajoute 3 zombies de plus à la prochaine vague 
                                wave_zombiesIngame = wave_zombies_Tohave;

                              
                                WaitFinishedWave();                                 //on actionne le compte à rebours qui se produit entre chaque vague 

                      
                            
                                
                                finishedwave = true;
                                
                            }
                            else   //il reste des zombies 
                            {

                                if (wave_zombies_Tohave - wave_zombieSummoned >0)   //si sur les zombies restant il reste des zombies non invoqués 
                                {
                                    MakeZombies();              //on en fait apparaitre un 
                                }
                                
                            }
                        }
                    }
                }


            }


        }

        private void KeyIsDown(object sender, KeyEventArgs e) // si la touche fleche bas est pressée
        {

            if (gameOver == true)    //il ne se passe rien 
            {
                return;
            }

            if (e.KeyCode == Keys.Left)    
            {
                goLeft = true;
                facing = "left";
                playerBox.Image = skullsnbones.Properties.Resources.left;                                                   // gestion des direction  
            }

            if (e.KeyCode == Keys.Right)
            {
                goRight = true;
                facing = "right";
                playerBox.Image = skullsnbones.Properties.Resources.right;
            }

            if (e.KeyCode == Keys.Up)
            {
                goUp = true;
                facing = "up";
                playerBox.Image = skullsnbones.Properties.Resources.up;
            }

            if (e.KeyCode == Keys.Down)
            {
                goDown = true;
                facing = "down";
                playerBox.Image = skullsnbones.Properties.Resources.down;
            }



        }

        private void KeyIsUp(object sender, KeyEventArgs e)  // si la touche fleche bas est pressée
        {
            if (e.KeyCode == Keys.Left)
            {
                goLeft = false;
            }

            if (e.KeyCode == Keys.Right)                    //gestion des directions
            {
                goRight = false;
            }

            if (e.KeyCode == Keys.Up)
            {
                goUp = false;
            }

            if (e.KeyCode == Keys.Down)
            {
                goDown = false;
            }

            if (e.KeyCode == Keys.P && !gameOver)  //si la touche de pause est pressée 
            {
                if (!isInpause )            //si la touche de pause est pressée pour la première fois 
                {
                    isInpause = true; // le jeu est mis en pause 
                    GameTimer.Stop();
                  
                    if (!WaitWaveMessage.Enabled &&  !WaitPlayer.Enabled)  
                    {
                        pauseLabel.Visible = true; pauseLabel.Visible = true;
                    }
                }
                else //si le jeu est déja en pause 
                {
                    isInpause = false;
                    pauseLabel.Visible = false;
                    GameTimer.Start();   //le jeu reprends
                    
                }
            }


            if (e.KeyCode == Keys.Space && playerAmmo > 0 && gameOver == false)  // si le joueur a encore des munitions et  tire  
            {
                playerAmmo--;
                ammoLabel.ForeColor = System.Drawing.Color.White;
                ShootBullet(facing);        //tire une balle dans la direction du joueur 


                if (playerAmmo < 1)  // si le joueur n'a plus de balle 
                {
                    ammoLabel.Text = "Out Of Ammo ! (" + playerAmmo + ")";  // le texte de munition informe le joueur 
                    ammoLabel.ForeColor = System.Drawing.Color.Red;
                    //GameTimer_Tick();

                    DropAmmo(); // des munitions sont lachées quelque part sur la zone de jeu 

                }
            }

            if (e.KeyCode == Keys.Space && gameOver == true && dataSend == true ) // si le joueur veut relancer le jeu 
            {
                

                RestartGame(); // relance le jeu 
                dataSend = false;
               
                



            }

        }
   


        private void SendDataToDataBase()  // envoie les données vers la base de données
        {
            string connectionString = "Server=sql.freedb.tech;Port=3306;Uid=freedb_main-user;Pwd=ERbJH#pM8C8%pdT;Database=freedb_resultsdb;";

            MySqlConnection connection = new MySqlConnection(connectionString);         // création d'une nouvelle connexion

            try
            {
                connection.Open();                                                      //ouverture de la connexion 



                Console.WriteLine("Connexion réussie!");

                string Query = "insert into results (username,score,kills) values (" + "'" + playerName + "'" + "," + playerScore + "," + playerKills + ")";        //insertion des valeurs de partie dans la base de données 
                Debug.Print(Query);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, connection); 
                MySqlDataReader MyReader2;
                MyReader2 = MyCommand2.ExecuteReader();   //execution de la requete 



                connection.Close();//fermeture de la connexion 

            }
            catch (Exception ex)
            {
                Console.WriteLine("Erreur de connexion: " + ex.Message + " " + ex.InnerException);
            }
        }



        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void ShootBullet(string direction) //fonction de tir de la balle 
        {
            Bullet shootBullet = new Bullet();                                     //instantiation du sprite 
            shootBullet.direction = direction;                                    //direction du joueur 
            shootBullet.bulletLeft = playerBox.Left + (playerBox.Width / 2);
            shootBullet.bulletTop = playerBox.Top + (playerBox.Height / 2);
            shootBullet.MakeBullet(this);                                        // fonction de création  et du comportement  de la balle 
        }

        private void MakeZombies()                                  // fonction de création du zombie 
        {
            wave_zombieSummoned++;                                  //un zombie de plus a été invoqué 
            PictureBox zombie = new PictureBox();                    //ajout du sprite 
            zombie.Tag = "zombie";
            zombie.Image = skullsnbones.Properties.Resources.zdown;  //ajout de l'image du sprite 
            zombie.Left = randNum.Next(0, 900);                      // le zombie est invoqué de manière aléatoire dans la zone de jeu 
            zombie.Top = randNum.Next(0, 800);
            zombie.SizeMode = PictureBoxSizeMode.AutoSize;          //redimentionement de l'image automatique 
            zombiesList.Add(zombie);                                //ajout à la liste du zombie 
            this.Controls.Add(zombie);
            playerBox.BringToFront();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }



        private void DropAmmo()                 //fonction de création de boite de munition dans un endroit alétoire du jeu
        {

            PictureBox ammo = new PictureBox();      //nouveau sprite 
            ammo.Image = skullsnbones.Properties.Resources.ammo_Image;   //image 
            ammo.SizeMode = PictureBoxSizeMode.AutoSize;
            ammo.Left = randNum.Next(10, this.ClientSize.Width - ammo.Width); //apparait dans une zone alétoire de la zone de jeu 
            ammo.Top = randNum.Next(60, this.ClientSize.Height - ammo.Height);
            ammo.Tag = "ammo";
            this.Controls.Add(ammo);
            bulletList.Add(ammo);
            ammo.BringToFront();
            playerBox.BringToFront();



        }


        public void LootAmmo(Control x)    //fonction de création de munition  là ou le zombie mort  a laché les munitions 
        {

            PictureBox ammo = new PictureBox();
            ammo.Image = skullsnbones.Properties.Resources.ammo_Image;
            ammo.SizeMode = PictureBoxSizeMode.AutoSize;
            ammo.Left = x.Bounds.Left;

            ammo.Top = x.Bounds.Top;
            ammo.Tag = "ammo";
            this.Controls.Add(ammo);
            bulletList.Add(ammo);

            ammo.BringToFront();
            playerBox.BringToFront();



        }

        private void GameOverMsg_Click(object sender, EventArgs e)
        {

        }

        public void DropHeal(Control x) //fonction de création de soins  la ou les zombie est mort
        {
            if (healList.Count < 3)
            {
                PictureBox carekit = new PictureBox();                      //nouveau sprite
                carekit.Image = skullsnbones.Properties.Resources.health; 
                carekit.SizeMode = PictureBoxSizeMode.AutoSize;
                carekit.Left = x.Bounds.Left;  
                carekit.Top = x.Bounds.Top;
                carekit.Tag = "heal";
                this.Controls.Add(carekit);
                healList.Add(carekit);

                carekit.BringToFront();

                playerBox.BringToFront();
            }
        }



        public void RestartGame() //fonction pour relancer le jeu 

        {

             zombieKilled = 0;
             gameWave = 1;
            waveLabel.Text = "Wave " + gameWave;
            playerKills = 0;
            playerScore = 0;
           
             wave_zombiesIngame = 5;                   //réinitialisation des valeurs 
             wave_zombieSummoned = 0;
             wave_zombies_Tohave = 5;
             wave_zombie_killed = 0;
             finishedwave = false;
             duration_waveMessage = 5;
             zombie_spawnDelay = 5;
             isClosed = false;
            game_WaitDuration = 5;
            this.healthBar.ForeColor = System.Drawing.Color.Green;   

            gameOverMsg.Visible = false;                            // on cache le message de fin de jeu

            playerBox.Image = skullsnbones.Properties.Resources.up;

            foreach (PictureBox i in zombiesList)  // on enlève tout les zombies, les trousses de soins et les trousses de munitions
            {
                this.Controls.Remove(i);
            }

            foreach (PictureBox i in healList)
            {
                this.Controls.Remove(i);
            }
            foreach (PictureBox i in bulletList)
            {
                this.Controls.Remove(i);
            }

            zombiesList.Clear();  //on vide tout les listes
            healList.Clear();
            bulletList.Clear();


            for (int i = 0; i < 3; i++) // on invoque les zombies de la première vague
            {
                MakeZombies();
                
            }
            

            goUp = false;
            goDown = false;
            goLeft = false;
            goRight = false;
            gameOver = false;                           //on réinitialise les valeurs de jeu 

            playerHealth = 100;
            playerKills = 0;
            playerAmmo = 10;

            GameTimer.Start();
        }

        public void WaitForPlayer()   //on enclenche la minuterie qui permet d'avoir 5 secondes de repis au joueur avant la première vague 
        {
            is_spawner_handler_subscribed = true;
            WaitPlayer.Interval = 1000;
            WaitPlayer.Tick += new EventHandler(Count_down);
            WaitPlayer.Start();
          
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void txtScore_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void txtAmmo_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void healthBar_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        public void WaitFinishedWave() // on enclenche la minuterie  qui permet au joueur d'avoir du repos entre deux vagues 
        {
           if (!is_wave_wait_subscribed)
            {
                is_wave_wait_subscribed = true;
                WaveMsg.Visible = true;
                WaveMsg.Text = "Wave" + gameWave;
                WaitWaveMessage.Interval = 1000;
                WaitWaveMessage.Tick += new EventHandler(CountDownWaveMsg);
                WaitWaveMessage.Start();
                
            }
            else
            {
                WaveMsg.Visible = true;
                WaitWaveMessage.Start();
            }
       
        }





        private void Count_down(object sender, EventArgs e)  //compte à rebours pour la minuterie qui permet au joueur d'avoir du repis avant la premier vague 
        {
            if (game_WaitDuration == 0)
            {

               
               WaitPlayer.Stop(); // on stoppe la minuterie quand le temps est écoulé
                RestartGame();
                game_WaitDuration = 5; //on réinitalise le compte à rebours 

            }
            else if (game_WaitDuration > 0) //si le compte a rebours n'est pas écoulé 
            {
                game_WaitDuration--;
                timerLabel.Text = game_WaitDuration.ToString(); //actualisation du minuteur 
            }
        }

        private void CountDownWaveMsg(object sender, EventArgs e)   //compte à rebours pour la minuterie qui permet au joueur d'avoir du repis entre deux vague 
        {
            if (duration_waveMessage == 0)
            {

                if ((gameWave % 5) == 0) // tout les 5 vagues 
                {
                   
                    playerAmmo = player_maxAmmo;

                    if (gameWave > 10) //si la vague est plus haute que la vague 10 

                    {
                        player_maxAmmo = player_maxAmmo + 20; // le joueur voit ses munitions maximum augmentées de 20 
                    }
                    else
                    {
                        player_maxAmmo = player_maxAmmo + 10; // seulement de 10 si la vague est plus basse que la vague 10 
                        
                    }
                }
              

                WaitWaveMessage.Stop(); // arret de la minuterie 
                WaveMsg.Visible = false; //le message est caché 

               
                duration_waveMessage = 5;
                finishedwave = false;
             
                 if (wave_zombiesIngame > 2) // pour empecher qu'il y ait trop de zombie dans le jeu 
                {
                    
                int    instant_spawned_zombie = (int)(wave_zombies_Tohave / 2); // la moitié de zombie de la vague  apparaissent au début de la vague 

                    if (instant_spawned_zombie>40) // le maximum de zombie dans le jeu est de 40 
                    {
                        instant_spawned_zombie = 40;
                    }

                    for (int i = 0; i < instant_spawned_zombie; i++) //on fait apparaitre la moitié des zombie
                    {
                        MakeZombies();

                    }
                }
             
                
                   
               

            }
            else if (duration_waveMessage > 0)
            {
                duration_waveMessage--;
                timerLabel.Text = "" + duration_waveMessage.ToString();
            }
        }



    }
    
}
