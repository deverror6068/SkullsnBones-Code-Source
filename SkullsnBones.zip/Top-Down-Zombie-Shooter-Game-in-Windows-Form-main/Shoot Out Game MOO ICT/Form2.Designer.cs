﻿namespace Skullsnbones
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.PseudoInput = new System.Windows.Forms.TextBox();
            this.confirmButton = new System.Windows.Forms.Button();
            this.infoLabel = new System.Windows.Forms.Label();
            this.errornameLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // PseudoInput
            // 
            this.PseudoInput.Location = new System.Drawing.Point(301, 188);
            this.PseudoInput.Name = "PseudoInput";
            this.PseudoInput.Size = new System.Drawing.Size(124, 20);
            this.PseudoInput.TabIndex = 0;
            // 
            // confirmButton
            // 
            this.confirmButton.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.confirmButton.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.confirmButton.ForeColor = System.Drawing.Color.Black;
            this.confirmButton.Location = new System.Drawing.Point(316, 230);
            this.confirmButton.Name = "confirmButton";
            this.confirmButton.Size = new System.Drawing.Size(88, 34);
            this.confirmButton.TabIndex = 1;
            this.confirmButton.Text = "Confirm";
            this.confirmButton.UseVisualStyleBackColor = false;
            this.confirmButton.Click += new System.EventHandler(this.Confirm_Click);
            // 
            // infoLabel
            // 
            this.infoLabel.AutoSize = true;
            this.infoLabel.BackColor = System.Drawing.Color.Transparent;
            this.infoLabel.Font = new System.Drawing.Font("Segoe UI Historic", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.infoLabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.infoLabel.Location = new System.Drawing.Point(232, 136);
            this.infoLabel.Name = "infoLabel";
            this.infoLabel.Size = new System.Drawing.Size(320, 23);
            this.infoLabel.TabIndex = 2;
            this.infoLabel.Text = "Enter a pseudonym (without spaces)";
            this.infoLabel.Click += new System.EventHandler(this.Info1_Click);
            // 
            // errornameLabel
            // 
            this.errornameLabel.AutoSize = true;
            this.errornameLabel.BackColor = System.Drawing.Color.Transparent;
            this.errornameLabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errornameLabel.ForeColor = System.Drawing.Color.Red;
            this.errornameLabel.Location = new System.Drawing.Point(297, 283);
            this.errornameLabel.Name = "errornameLabel";
            this.errornameLabel.Size = new System.Drawing.Size(147, 22);
            this.errornameLabel.TabIndex = 3;
            this.errornameLabel.Text = "Invalid username";
            this.errornameLabel.Visible = false;
            this.errornameLabel.Click += new System.EventHandler(this.ErrorName_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.errornameLabel);
            this.Controls.Add(this.infoLabel);
            this.Controls.Add(this.confirmButton);
            this.Controls.Add(this.PseudoInput);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form2";
            this.Text = "Entrez votre pseudo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox PseudoInput;
        private System.Windows.Forms.Button confirmButton;
        private System.Windows.Forms.Label infoLabel;
        private System.Windows.Forms.Label errornameLabel;
    }
}