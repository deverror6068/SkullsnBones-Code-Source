﻿using Skullsnbones;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Skullsnbones
{
    public partial class Form2 : Form
    {
       
        public Form2()
        {
            InitializeComponent();
          
        }

     

        public void Confirm_Click(object sender, EventArgs e)
        {
            errornameLabel.Visible = false;
            
           



            if (PseudoInput.Text.Length>0 && !PseudoInput.Text.Contains(" "))//si le pseudo ne  contient pas  des espaces 
            {

                
               
              
               this.Hide(); //on cache le formulaire et on lance le jeu 
                Form1 newgame = new Form1();
                newgame.Show();
                newgame.SetPlayerName(PseudoInput.Text); // on envoie le nom du joueur au jeu 
                newgame.InitializeComponent();
                newgame.WaitForPlayer();
              
             
              if(newgame.isClosed){  //si le jeu est fermé on ferme le formulaire 
                    this.Close();
                }
                

            }
            else
            {
                errornameLabel.Visible = true; //on afficher l'erreur 
               
            }
        }

        public void DestroyForm()
        {
            
        }

        private void Info1_Click(object sender, EventArgs e)
        {

        }

        private void ErrorName_Click(object sender, EventArgs e)
        {

        }
    }
}
