﻿namespace Skullsnbones
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        public void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.timerLabel = new System.Windows.Forms.Label();
            this.ammoLabel = new System.Windows.Forms.Label();
            this.killsLabel = new System.Windows.Forms.Label();
            this.healthBar = new System.Windows.Forms.ProgressBar();
            this.GameTimer = new System.Windows.Forms.Timer(this.components);
            this.scoreLabel = new System.Windows.Forms.Label();
            this.gameOverMsg = new System.Windows.Forms.PictureBox();
            this.playerBox = new System.Windows.Forms.PictureBox();
            this.WaveMsg = new System.Windows.Forms.Label();
            this.waveLabel = new System.Windows.Forms.Label();
            this.killsBox = new System.Windows.Forms.PictureBox();
            this.scoreBox = new System.Windows.Forms.PictureBox();
            this.ammoBox = new System.Windows.Forms.PictureBox();
            this.heartBox = new System.Windows.Forms.PictureBox();
            this.nextwaveLabel = new System.Windows.Forms.Label();
            this.pauseLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.gameOverMsg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.killsBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.scoreBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ammoBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartBox)).BeginInit();
            this.SuspendLayout();
            // 
            // timerLabel
            // 
            this.timerLabel.AutoSize = true;
            this.timerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timerLabel.ForeColor = System.Drawing.Color.White;
            this.timerLabel.Location = new System.Drawing.Point(597, 19);
            this.timerLabel.Name = "timerLabel";
            this.timerLabel.Size = new System.Drawing.Size(57, 24);
            this.timerLabel.TabIndex = 17;
            this.timerLabel.Text = "Time";
            this.timerLabel.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // ammoLabel
            // 
            this.ammoLabel.AutoSize = true;
            this.ammoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ammoLabel.ForeColor = System.Drawing.Color.Black;
            this.ammoLabel.Location = new System.Drawing.Point(62, 21);
            this.ammoLabel.Name = "ammoLabel";
            this.ammoLabel.Size = new System.Drawing.Size(70, 24);
            this.ammoLabel.TabIndex = 0;
            this.ammoLabel.Text = "Ammo";
            this.ammoLabel.Click += new System.EventHandler(this.txtAmmo_Click);
            // 
            // killsLabel
            // 
            this.killsLabel.AutoSize = true;
            this.killsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.killsLabel.ForeColor = System.Drawing.Color.Black;
            this.killsLabel.Location = new System.Drawing.Point(285, 23);
            this.killsLabel.Name = "killsLabel";
            this.killsLabel.Size = new System.Drawing.Size(43, 24);
            this.killsLabel.TabIndex = 0;
            this.killsLabel.Text = "Kills";
            this.killsLabel.Click += new System.EventHandler(this.txtScore_Click);
            // 
            // healthBar
            // 
            this.healthBar.BackColor = System.Drawing.Color.DimGray;
            this.healthBar.ForeColor = System.Drawing.Color.Green;
            this.healthBar.Location = new System.Drawing.Point(725, 20);
            this.healthBar.Name = "healthBar";
            this.healthBar.Size = new System.Drawing.Size(187, 23);
            this.healthBar.TabIndex = 1;
            this.healthBar.Value = 100;
            this.healthBar.Click += new System.EventHandler(this.healthBar_Click);
            // 
            // GameTimer
            // 
            this.GameTimer.Enabled = true;
            this.GameTimer.Interval = 20;
            this.GameTimer.Tick += new System.EventHandler(this.MainTimerEvent);
            // 
            // scoreLabel
            // 
            this.scoreLabel.AutoSize = true;
            this.scoreLabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scoreLabel.Location = new System.Drawing.Point(161, 22);
            this.scoreLabel.Name = "scoreLabel";
            this.scoreLabel.Size = new System.Drawing.Size(63, 25);
            this.scoreLabel.TabIndex = 6;
            this.scoreLabel.Text = "Score";
            this.scoreLabel.Click += new System.EventHandler(this.label4_Click);
            // 
            // gameOverMsg
            // 
            this.gameOverMsg.BackgroundImage = global::skullsnbones.Properties.Resources.gameover;
            this.gameOverMsg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.gameOverMsg.Location = new System.Drawing.Point(87, 270);
            this.gameOverMsg.Name = "gameOverMsg";
            this.gameOverMsg.Size = new System.Drawing.Size(737, 65);
            this.gameOverMsg.TabIndex = 5;
            this.gameOverMsg.TabStop = false;
            this.gameOverMsg.Visible = false;
            this.gameOverMsg.Click += new System.EventHandler(this.GameOverMsg_Click);
            // 
            // playerBox
            // 
            this.playerBox.Image = global::skullsnbones.Properties.Resources.up;
            this.playerBox.Location = new System.Drawing.Point(427, 471);
            this.playerBox.Name = "playerBox";
            this.playerBox.Size = new System.Drawing.Size(71, 100);
            this.playerBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.playerBox.TabIndex = 2;
            this.playerBox.TabStop = false;
            // 
            // WaveMsg
            // 
            this.WaveMsg.AutoSize = true;
            this.WaveMsg.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WaveMsg.Location = new System.Drawing.Point(422, 133);
            this.WaveMsg.Name = "WaveMsg";
            this.WaveMsg.Size = new System.Drawing.Size(64, 25);
            this.WaveMsg.TabIndex = 7;
            this.WaveMsg.Text = "label5";
            this.WaveMsg.Visible = false;
            // 
            // waveLabel
            // 
            this.waveLabel.AutoSize = true;
            this.waveLabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 20F, System.Drawing.FontStyle.Bold);
            this.waveLabel.Location = new System.Drawing.Point(339, 14);
            this.waveLabel.Name = "waveLabel";
            this.waveLabel.Size = new System.Drawing.Size(117, 36);
            this.waveLabel.TabIndex = 11;
            this.waveLabel.Text = "Wave 1";
            this.waveLabel.Click += new System.EventHandler(this.label5_Click);
            // 
            // killsBox
            // 
            this.killsBox.Image = ((System.Drawing.Image)(resources.GetObject("killsBox.Image")));
            this.killsBox.Location = new System.Drawing.Point(230, 10);
            this.killsBox.Name = "killsBox";
            this.killsBox.Size = new System.Drawing.Size(35, 37);
            this.killsBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.killsBox.TabIndex = 12;
            this.killsBox.TabStop = false;
            this.killsBox.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // scoreBox
            // 
            this.scoreBox.Image = ((System.Drawing.Image)(resources.GetObject("scoreBox.Image")));
            this.scoreBox.Location = new System.Drawing.Point(120, 14);
            this.scoreBox.Name = "scoreBox";
            this.scoreBox.Size = new System.Drawing.Size(35, 37);
            this.scoreBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.scoreBox.TabIndex = 13;
            this.scoreBox.TabStop = false;
            // 
            // ammoBox
            // 
            this.ammoBox.Image = ((System.Drawing.Image)(resources.GetObject("ammoBox.Image")));
            this.ammoBox.Location = new System.Drawing.Point(21, 13);
            this.ammoBox.Name = "ammoBox";
            this.ammoBox.Size = new System.Drawing.Size(35, 37);
            this.ammoBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ammoBox.TabIndex = 14;
            this.ammoBox.TabStop = false;
            // 
            // heartBox
            // 
            this.heartBox.Image = ((System.Drawing.Image)(resources.GetObject("heartBox.Image")));
            this.heartBox.Location = new System.Drawing.Point(687, 15);
            this.heartBox.Name = "heartBox";
            this.heartBox.Size = new System.Drawing.Size(32, 29);
            this.heartBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.heartBox.TabIndex = 15;
            this.heartBox.TabStop = false;
            this.heartBox.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // nextwaveLabel
            // 
            this.nextwaveLabel.AutoSize = true;
            this.nextwaveLabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nextwaveLabel.Location = new System.Drawing.Point(471, 21);
            this.nextwaveLabel.Name = "nextwaveLabel";
            this.nextwaveLabel.Size = new System.Drawing.Size(120, 22);
            this.nextwaveLabel.TabIndex = 16;
            this.nextwaveLabel.Text = "Next wave in ";
            this.nextwaveLabel.Click += new System.EventHandler(this.label6_Click);
            // 
            // pauseLabel
            // 
            this.pauseLabel.AutoSize = true;
            this.pauseLabel.Font = new System.Drawing.Font("Myanmar Text", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pauseLabel.Location = new System.Drawing.Point(338, 171);
            this.pauseLabel.Name = "pauseLabel";
            this.pauseLabel.Size = new System.Drawing.Size(234, 58);
            this.pauseLabel.TabIndex = 18;
            this.pauseLabel.Text = "Game Paused";
            this.pauseLabel.Visible = false;
            this.pauseLabel.Click += new System.EventHandler(this.label8_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(924, 661);
            this.Controls.Add(this.pauseLabel);
            this.Controls.Add(this.timerLabel);
            this.Controls.Add(this.nextwaveLabel);
            this.Controls.Add(this.heartBox);
            this.Controls.Add(this.ammoBox);
            this.Controls.Add(this.ammoLabel);
            this.Controls.Add(this.scoreBox);
            this.Controls.Add(this.killsBox);
            this.Controls.Add(this.waveLabel);
            this.Controls.Add(this.WaveMsg);
            this.Controls.Add(this.scoreLabel);
            this.Controls.Add(this.gameOverMsg);
            this.Controls.Add(this.playerBox);
            this.Controls.Add(this.healthBar);
            this.Controls.Add(this.killsLabel);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Skulls\'nBones";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyIsDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.KeyIsUp);
            ((System.ComponentModel.ISupportInitialize)(this.gameOverMsg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.killsBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.scoreBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ammoBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label ammoLabel;
        private System.Windows.Forms.Label killsLabel;
        private System.Windows.Forms.Label timerLabel;
        private System.Windows.Forms.ProgressBar healthBar;
        private System.Windows.Forms.PictureBox playerBox;
        private System.Windows.Forms.Timer GameTimer;
        private System.Windows.Forms.PictureBox gameOverMsg;
        private System.Windows.Forms.Label scoreLabel;
        private System.Windows.Forms.Label WaveMsg;
        private System.Windows.Forms.Label waveLabel;
        private System.Windows.Forms.PictureBox killsBox;
        private System.Windows.Forms.PictureBox scoreBox;
        private System.Windows.Forms.PictureBox ammoBox;
        private System.Windows.Forms.PictureBox heartBox;



        private System.Windows.Forms.Label nextwaveLabel;
        private System.Windows.Forms.Label pauseLabel;
    }
}

